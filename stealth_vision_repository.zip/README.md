# Stealth-Black Machine Vision Tracking System

This repository provides zero-latency software pipelines designed to track physical hardware using a single-color, **dual-texture (Gloss-on-Matte)** molding pattern. This engineering setup allows the hardware to remain 100% blacked-out ("stealth") to the human eye while producing clear, high-contrast machine-vision tracking triggers for standard RGB cameras by capturing specular reflections.

## Manufacturing Architecture (Dual-Texture Blueprint)
* **The Protective Pocket:** Sunk 1.5mm down into the main hardware casing to protect the marker patterns against surface friction, abrasion, and scratches.
* **The Background (Matte):** Mold-Tech `MT-11020` or `MT-11030` heavy bead-blast finish. Traps and scatters overhead light to stay dull black to the sensor.
* **The Target Shapes (Gloss):** Diamond-buff mirror-polished surface (`SPI A-1` or `SPI A-2`). Bounces directional light back to create bright white pixel groupings.

---

## Tracking Pipeline Implementation Details

### Pipeline 1: ArUco / QR Module (`track_aruco_optimized.py`)
* **Primary Use Case:** Full 3D pose estimation, precise spatial mapping, and 6-DOF coordinate retrieval.
* **Algorithmic Logic:** Utilizes a pixel-level full-frame or regional bitwise inversion (`cv2.bitwise_not`). This instantly converts shiny reflected code elements to solid binary black features on an artificially clean white background, allowing native detection algorithms to read the marker seamlessly.

### Pipeline 2: Custom Infinity Logo (`track_infinity_ultra_fast.py`)
* **Primary Use Case:** Absolute minimum latency operations, high FPS execution on edge microcontrollers, and branding integration.
* **Algorithmic Logic:** Completely bypasses heavy contour-chain exploration. Uses single-pass Connected Component Labeling (`connectedComponentsWithStats`) combined with high-speed bounding-box geometric aspect ratio verification.
* **Orientation Detection:** Employs an asymmetrical anchor point configuration to determine physical rotation from center-mass variance instantaneously without adding runtime overhead.

---

## Installation & Dependecies
Ensure your runtime environment has the standard Open Source Computer Vision dependencies installed:
```bash
pip install opencv-python numpy
```

---

## License
Open-Source Engineering Blueprint. Provided for automated manufacturing, robotics sorting pipelines, and interactive tactical hardware integrations.
