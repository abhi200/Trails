import cv2

# Initialize camera matrix stream
cap = cv2.VideoCapture(0)

# Configure default ArUco 4x4 matrix parameters
dictionary = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50)
parameters = cv2.aruco.DetectorParameters()

# Customize internal tracking parameters to favor mirror flash properties
parameters.adaptiveThreshWinSizeMin = 3
parameters.adaptiveThreshWinSizeMax = 23
parameters.adaptiveThreshWinSizeStep = 10
parameters.adaptiveThreshConstant = 7

detector = cv2.aruco.ArucoDetector(dictionary, parameters)

print("Starting Low-Overhead ArUco Engine...")

while True:
    ret, frame = cap.read()
    if not ret:
        break
        
    # Convert incoming sensor frame to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    
    # Critical Step: Hardware inversion step
    # Flips specular mirror bursts to binary dark zones for standard engine processing
    inverted_frame = cv2.bitwise_not(gray)
    
    # Detect target landmarks
    corners, ids, rejected = detector.detectMarkers(inverted_frame)
    
    # Render tracking visualization directly onto the source RGB array
    if ids is not None:
        cv2.aruco.drawDetectedMarkers(frame, corners, ids)
        
    cv2.imshow("Optimized Dual-Texture ArUco Stream", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
